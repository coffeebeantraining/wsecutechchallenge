package com.wsecutechchallenge.app.ws.ui.model.response;

/**
 *
 * @author mark.jones
 */
public enum RequestOperationStatus {
    SUCCESS,
    ERROR
}
