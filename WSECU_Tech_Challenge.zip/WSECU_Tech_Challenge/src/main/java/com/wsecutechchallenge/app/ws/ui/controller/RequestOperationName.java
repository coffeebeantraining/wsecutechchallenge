package com.wsecutechchallenge.app.ws.ui.controller;

/**
 *
 * @author mark.jones
 */
public enum RequestOperationName {
    DELETE,
    VERIFY_EMAIL,
    REQUEST_PASSWORD_RESET,
    PASSWORD_RESET
}
