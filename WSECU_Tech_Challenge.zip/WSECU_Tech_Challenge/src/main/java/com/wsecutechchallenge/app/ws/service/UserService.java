package com.wsecutechchallenge.app.ws.service;

import com.wsecutechchallenge.app.ws.shared.dto.UserDto;

/**
 *
 * @author mark.jones
 */
public interface UserService {

    UserDto findUser(UserDto user);

    UserDto createUser(UserDto user);

    void deleteUser(String userId);

    UserDto updateUser(String userId, UserDto user);

}
