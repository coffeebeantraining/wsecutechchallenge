package com.wsecutechchallenge.app.ws.service.Impl;

import com.wsecutechchallenge.app.ws.UserRepository;
import com.wsecutechchallenge.app.ws.io.entity.UserEntity;
import com.wsecutechchallenge.app.ws.service.UserService;
import com.wsecutechchallenge.app.ws.shared.dto.UserDto;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author mark.jones
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;

    /**
     *
     * @param user
     * @return
     */
    @Override
    public UserDto findUser(UserDto user) {

        if (userRepository.findUserByUserId(user.getUserId()) == null) {
            throw new RuntimeException("userid does not exist.");
        }

        UserEntity userEntity = new UserEntity();
        BeanUtils.copyProperties(user, userEntity);
        UserEntity storedUserDetails = userRepository.findUserByUserId(userEntity.getUserId());

        UserDto returnValue = new UserDto();
        BeanUtils.copyProperties(storedUserDetails, returnValue);

        return returnValue;

    }

    /**
     *
     * @param user
     * @return
     */
    @Override
    public UserDto createUser(UserDto user) {

        if (userRepository.findUserByUserId(user.getUserId()) != null) {
            throw new RuntimeException("userid already exists.");
        }

        if (userRepository.findUserByEmail(user.getEmail()) != null) {
            throw new RuntimeException("email already exists.");
        }

        UserEntity userEntity = new UserEntity();
        BeanUtils.copyProperties(user, userEntity);

        userEntity.setEncryptedPassword("" + user.getPassword().hashCode());    //cannot be null

        UserEntity storedUserDetails = userRepository.save(userEntity);

        UserDto returnValue = new UserDto();
        BeanUtils.copyProperties(storedUserDetails, returnValue);

        return returnValue;

    }

    /**
     *
     * @param userId
     */
    @Override
    public void deleteUser(String userId) {

        UserEntity userEntity = userRepository.findUserByUserId(userId);

        if (userEntity == null) {
            throw new RuntimeException("No User Found.");
        }

        userRepository.delete(userEntity);

    }

    /**
     *
     * @param userId
     * @param user
     * @return
     */
    @Override
    public UserDto updateUser(String userId, UserDto user) {

        UserEntity userEntity = userRepository.findUserByUserId(userId);

        if (userEntity == null) {
            throw new RuntimeException("No record found.");
        }

        userEntity.setFirstName(user.getFirstName());
        userEntity.setLastName(user.getLastName());
        userEntity.setEmail(user.getEmail());

        UserEntity updatedUserDetails = userRepository.save(userEntity);

        UserDto returnValue = new UserDto();
        BeanUtils.copyProperties(updatedUserDetails, returnValue);

        return returnValue;
    }

}
